package jeroquest.units;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import jeroquest.boardgame.Dice;
import jeroquest.logic.Game;

public class DirtyRat extends Monster {

	// initial values for the attributes
	protected static final int MOVEMENT = 4;
	protected static final int ATTACK = 2;
	protected static final int DEFENCE = 2;
	protected static final int BODY = 5;

	protected boolean fearful;

	public boolean getFearful() {
		return fearful;
	}

	public void setFearful(boolean fearful) {
		this.fearful = fearful;
	}

	/**
	 * Create a mummy from its name
	 * 
	 * @param name name of the mummy
	 */
	public DirtyRat(String name) {
		super(name, MOVEMENT, ATTACK, DEFENCE, BODY);
		fearful = false;
	}

	/************************************************
	 * Interface Piece implementation
	 **********************************************/

	/**
	 * Generate a text representation of the character in the board (implementing an
	 * abstract method)
	 * 
	 * @return the text representation of the object in the board
	 */
	public char toChar() {
		return 'R';
	}

	/************************************************
	 * Interface GraphicElement implementation
	 **********************************************/

	// Icon of a mummy
	private static Icon icon = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/rata.png"));

	private static Icon icon2 = new ImageIcon(ClassLoader.getSystemResource("jeroquest/gui/images/rata_asustada.png"));

	public Icon getImage() {
		if (this.getFearful()) {
			return icon2;
		}
		else {
			return icon;
		}
	}

	@Override
	public boolean isEnemy(Character c) {
		return (super.isEnemy(c)) || (c.getBody() < this.getBody());
	}

	@Override
	public int defend(int impacts) {
		int wounds = super.defend(impacts);
		//si estaba asustada y sangra >= bodyinitial se muere
		if(this.getFearful() && wounds >= this.getBodyInitial()/2) {
			this.setBody(0);
		}
		else {
			//si me hacen heridas me asusto
			if(wounds > 0) this.setFearful(true);
		}
		return wounds;
	}

	@Override
	public void resolveTurn(Game currentGame) {

		if (this.getFearful()) {
			//No hago nada
			System.out.println(this.getName()+"esta asustada y no hace nada en su turno");
		}
		else {
			super.resolveTurn(currentGame);
		}

		// Attack to a random enemy
		actionCombat(currentGame);

		// Move randomly through the board
		actionMovement(currentGame);

		// Possibles improvement (among others):
		// - Move towards the closest enemy / with less body points /...
		// A.- First in Xs and later in Ys
		// B.- First in the coordinate with difference with the target's position
		// - AI: check if there is free way until the target
		// - What to do if our way is blocked by allies?
		// - Stop is there is an enemy at attack range
		// and if the square is free and inside of the board move to that position

	}

	@Override
	public String toString() {
		return super.toString()+"[fearful=" + fearful + "]";
	}

	public void regenerate() {
		if(this.getBody()<this.getBodyInitial()) {
			System.out.println(this.getName()+"Se le regenera 1 punto de vida");
			this.setBody(this.getBody()+1);
		}

	}



















}
